export default function NotFound(){
	return (
		<div>
			404 - Not found
		</div>
	)
}