import {Link} from "react-router-dom";
import {useRef} from "react";
import axiosClient from "../axios";

export default function Login(){
	const emailRef = useRef();
	const passwordRef = useRef();
	
	const onSubmit = (ev)=>{
		ev.preventDefault();
		const payload = {
			email: emailRef.current.value,
			password: passwordRef.current.value,
		}

		console.log(payload);
		
		axiosClient.post("/login", payload)
			.then(({data})=>{
				setUser(data.user)
				setToken(data.token)
				console.log(data);
			})
			.catch(err =>{
				const response = err.response;
				//if(response && response.status===422){
				console.log(response.data.errors);
			//}
		})
	}
	return (
		<form onSubmit={onSubmit}>
			<h1 className="title">
				Login to your account
			</h1>
			<input ref={emailRef} type="email" placeholder= "Email" />
			<input ref={passwordRef} type="password" placeholder= "Password" />
			<button className="btn btn-block">Login</button>
			<p className="message">
				Not Registered? <Link to="/register">Create an account</Link>
			</p>
		</form>
	)
}